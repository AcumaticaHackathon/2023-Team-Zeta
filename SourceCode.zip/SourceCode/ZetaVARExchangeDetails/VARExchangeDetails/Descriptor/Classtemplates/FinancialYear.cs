﻿namespace ZetaVARDataExchange
{
   
    public class FinInfo
    {
        public FinancialYear FinancialYear { get; set; }
    }


}
