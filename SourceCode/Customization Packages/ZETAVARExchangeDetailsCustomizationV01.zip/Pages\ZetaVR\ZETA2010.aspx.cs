using System;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Page_ZETA2010 : PX.Web.UI.PXPage
{
	protected void Page_Load(object sender, EventArgs e)
	{
	}
}
